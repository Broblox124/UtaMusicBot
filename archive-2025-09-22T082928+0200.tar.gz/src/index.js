// Manual environment setup (FIX for .env loading issues)
process.env.DISCORD_TOKEN = process.env.DISCORD_TOKEN || 'MTQxOTQ5NzM1MDg4MzMxMTYzNg.GfI8LQ.ime95qKWl1q6G9kKIprjwN-j7fxdsuj6dA9Vj4';
process.env.CLIENT_ID = process.env.CLIENT_ID || '1419497350883311636';
process.env.YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyBr8jOfmrWHubBfZRYXCeu6Sb_YMngVj8c';
process.env.SPOTIFY_CLIENT_ID = process.env.SPOTIFY_CLIENT_ID || '5ad13d7108e5432cbaa653d0dd323c24';
process.env.SPOTIFY_CLIENT_SECRET = process.env.SPOTIFY_CLIENT_SECRET || '55a6d85c4a01493db9c30ed36270f42f';
process.env.BOT_NAME = process.env.BOT_NAME || 'VibyMusic';
process.env.BOT_COLOR = process.env.BOT_COLOR || '#FF69B4';
process.env.PREFIX = process.env.PREFIX || '/';

// Try to load .env file as backup
try {
    require('dotenv').config();
    console.log('✅ .env file loaded successfully'.green);
} catch (error) {
    console.log('⚠️ Using manual environment config (this is normal)'.yellow);
}

const { Client, GatewayIntentBits, Collection, ActivityType, REST, Routes } = require('discord.js');
const { Player } = require('discord-player');
const fs = require('fs');
const path = require('path');
const colors = require('colors');
const AsciiTable = require('ascii-table');

// Initialize Discord client with MINIMAL intents (FIXED - NO PRIVILEGED INTENTS)
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildVoiceStates
    ]
});

// Initialize Discord Player with SIMPLER configuration (FIXED)
const player = new Player(client, {
    ytdlOptions: {
        quality: 'highestaudio',
        filter: 'audioonly',
        requestOptions: {
            timeout: 10000 // 10 second timeout
        }
    },
    skipFFmpeg: false,
    connectionTimeout: 20000, // 20 second connection timeout
    useLegacyFFmpeg: false
});

// Load extractors with BETTER error handling
let extractorsLoaded = false;
try {
    // Only load essential extractors to avoid timeouts
    player.extractors.loadDefault();
    extractorsLoaded = true;
    console.log('🎵 Player extractors loaded successfully!'.green);
} catch (error) {
    console.log('⚠️ Extractors failed to load, using fallback mode'.yellow);
    console.log('Error:', error.message);
    extractorsLoaded = false;
}

// Fallback extractor loading if main fails
if (!extractorsLoaded) {
    try {
        // Try to load just YouTube extractor
        const { YouTubeExtractor } = require('@discord-player/extractor');
        player.extractors.register(YouTubeExtractor, {});
        console.log('🎵 Fallback YouTube extractor loaded!'.cyan);
    } catch (fallbackError) {
        console.log('⚠️ All extractors failed, bot will use basic functionality'.red);
    }
}

// Create commands collection
client.commands = new Collection();
client.player = player;

// Load config with error handling
let config;
try {
    config = require('./config/config');
    console.log('✅ Config loaded successfully!'.green);
} catch (error) {
    console.error('❌ Failed to load config:', error.message);
    // Create basic config if file missing
    config = {
        botName: process.env.BOT_NAME,
        botColor: process.env.BOT_COLOR,
        emojis: {
            play: '▶️', pause: '⏸️', stop: '⏹️', skip: '⏭️',
            shuffle: '🔀', repeat: '🔁', queue: '📋', music: '🎵',
            love: '💖', sparkle: '✨', headphones: '🎧', notes: '🎶',
            success: '✅', error: '❌', warning: '⚠️', microphone: '🎤',
            radio: '📻', fire: '🔥', star: '⭐', heart: '💕', party: '🎉'
        },
        successEmbed: (title, description) => ({
            title: `✅ ${title}`,
            description: description,
            color: 0xFF69B4
        }),
        errorEmbed: (title, description) => ({
            title: `❌ ${title}`,
            description: description,
            color: 0xFF4444
        })
    };
    console.log('✅ Basic config created!'.yellow);
}

// Load musicUtils with error handling
let musicUtils;
try {
    musicUtils = require('./utils/musicUtils');
    console.log('✅ Music utils loaded successfully!'.green);
} catch (error) {
    console.log('⚠️ Music utils failed to load, continuing without Spotify features'.yellow);
    musicUtils = { 
        authenticateSpotify: () => console.log('Spotify authentication skipped'.yellow)
    };
}

// 🚀 AUTO-DEPLOY SLASH COMMANDS FUNCTION (IMPROVED WITH TIMEOUT)
async function deployCommands() {
    const commands = [];
    const commandsPath = path.join(__dirname, 'commands');
    
    try {
        const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
        
        console.log('📋 Loading commands for deployment...'.blue);
        
        for (const file of commandFiles) {
            const filePath = path.join(commandsPath, file);
            try {
                delete require.cache[require.resolve(filePath)]; // Clear cache
                const command = require(filePath);
                
                if ('data' in command && 'execute' in command) {
                    commands.push(command.data.toJSON());
                    console.log(`   ✅ Loaded: ${command.data.name}`.green);
                } else {
                    console.log(`   ⚠️ Skipped: ${file} (missing data/execute)`.yellow);
                }
            } catch (error) {
                console.log(`   ❌ Failed: ${file} (${error.message})`.red);
            }
        }
        
        if (commands.length === 0) {
            console.log('⚠️ No commands found to deploy, bot will still work without slash commands'.yellow);
            return;
        }
        
        // Deploy commands automatically with timeout protection
        const rest = new REST({ timeout: 15000 }).setToken(process.env.DISCORD_TOKEN);
        
        console.log(`🚀 Auto-deploying ${commands.length} slash commands...`.blue);
        
        // Use Promise.race to add our own timeout
        const deployPromise = rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: commands }
        );
        
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('Command deployment timed out')), 30000);
        });
        
        const data = await Promise.race([deployPromise, timeoutPromise]);
        
        console.log(`✅ Successfully deployed ${data.length} slash commands!`.green);
        console.log('🎵 Commands will appear in Discord within 1-5 minutes'.cyan);
        
        // List deployed commands
        console.log('📋 Deployed Commands:'.blue);
        data.forEach(cmd => {
            console.log(`   /${cmd.name} - ${cmd.description}`.cyan);
        });
        
    } catch (error) {
        console.error('❌ Failed to auto-deploy commands:', error.message);
        
        if (error.message.includes('timeout')) {
            console.error('🔧 Command deployment timed out - this is common on slower hosting'.yellow);
            console.error('Commands may still be deployed, wait 5 minutes and try using them'.yellow);
        } else if (error.code === 50001) {
            console.error('🔧 Missing access - Bot needs applications.commands scope'.yellow);
        } else if (error.code === 'TokenInvalid') {
            console.error('🔧 Invalid token - Check your DISCORD_TOKEN'.yellow);
        }
        
        console.log('⚠️ Bot will continue without slash commands'.yellow);
    }
}

// Load commands (for bot functionality)
const commandsPath = path.join(__dirname, 'commands');
let commandFiles = [];

try {
    commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
} catch (error) {
    console.error('❌ Commands folder not found:', error.message);
    console.log('⚠️ Bot will continue without custom commands'.yellow);
}

const commandTable = new AsciiTable('🎵 VibyMusic Commands');
commandTable.setHeading('Command', 'Status');

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    try {
        delete require.cache[require.resolve(filePath)]; // Clear cache
        const command = require(filePath);
        
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
            commandTable.addRow(command.data.name, '✅ Loaded'.green);
        } else {
            commandTable.addRow(file, '❌ Missing data/execute'.red);
        }
    } catch (error) {
        commandTable.addRow(file, '❌ Error loading'.red);
        console.error(`Error loading command ${file}:`, error.message);
    }
}

if (commandFiles.length > 0) {
    console.log(commandTable.toString());
}

// Load events
const eventsPath = path.join(__dirname, 'events');
let eventFiles = [];

try {
    eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
} catch (error) {
    console.error('❌ Events folder not found:', error.message);
    console.log('⚠️ Bot will continue without custom events'.yellow);
}

const eventTable = new AsciiTable('🎧 VibyMusic Events');
eventTable.setHeading('Event', 'Status');

for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    try {
        delete require.cache[require.resolve(filePath)]; // Clear cache
        const event = require(filePath);
        
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
        
        eventTable.addRow(event.name, '✅ Loaded'.green);
    } catch (error) {
        eventTable.addRow(file, '❌ Error loading'.red);
        console.error(`Error loading event ${file}:`, error.message);
    }
}

if (eventFiles.length > 0) {
    console.log(eventTable.toString());
}

// Player events with BETTER error handling
player.events.on('playerStart', (queue, track) => {
    try {
        console.log(`🎵 Now playing: ${track.title} in ${queue.guild.name}`.cyan);
    } catch (error) {
        console.log(`🎵 Now playing a track`.cyan);
    }
});

player.events.on('playerSkip', (queue, track) => {
    try {
        console.log(`⏭️ Skipped: ${track.title}`.yellow);
    } catch (error) {
        console.log(`⏭️ Skipped a track`.yellow);
    }
});

player.events.on('disconnect', (queue) => {
    try {
        console.log(`👋 Disconnected from ${queue.guild.name}`.magenta);
    } catch (error) {
        console.log(`👋 Disconnected from a server`.magenta);
    }
});

player.events.on('emptyChannel', (queue) => {
    try {
        console.log(`💤 Left empty voice channel in ${queue.guild.name}`.gray);
    } catch (error) {
        console.log(`💤 Left empty voice channel`.gray);
    }
});

player.events.on('emptyQueue', (queue) => {
    try {
        console.log(`📭 Queue finished in ${queue.guild.name}`.blue);
    } catch (error) {
        console.log(`📭 Queue finished`.blue);
    }
});

// IMPROVED player error handling
player.events.on('error', (queue, error) => {
    console.log(`❌ Player error:`.red, error.message);
    
    // Handle specific errors
    if (error.message.includes('timeout')) {
        console.log('🔧 Timeout error - trying to reconnect...'.yellow);
    } else if (error.message.includes('ECONNRESET')) {
        console.log('🔧 Connection reset - this is normal, will retry...'.yellow);
    }
});

player.events.on('playerError', (queue, error) => {
    console.log(`❌ Player playback error:`.red, error.message);
});

// Initialize Spotify with error handling
if (musicUtils && musicUtils.authenticateSpotify) {
    try {
        musicUtils.authenticateSpotify();
    } catch (error) {
        console.log('⚠️ Spotify authentication failed, continuing without it'.yellow);
    }
}

// Built-in ready event (in case custom ready.js fails)
client.once('ready', async () => {
    console.log(`💖 ${config.botName || 'VibyMusic'} is now online and ready to vibe!`.rainbow);
    console.log(`🎧 Connected to ${client.guilds.cache.size} servers with ${client.users.cache.size} users!`.cyan);
    
    // 🚀 AUTO-DEPLOY COMMANDS WHEN BOT IS READY (with delay to avoid conflicts)
    setTimeout(async () => {
        await deployCommands();
    }, 3000); // 3 second delay
    
    // Set bot activity with rotating messages
    const activities = [
        { name: 'your favorite tunes 🎵', type: ActivityType.Listening },
        { name: 'beats that make you dance 💃', type: ActivityType.Listening },
        { name: 'music that touches your soul 💖', type: ActivityType.Listening },
        { name: '/play to start the vibe ✨', type: ActivityType.Watching },
        { name: 'Spotify playlists 🎧', type: ActivityType.Streaming, url: 'https://open.spotify.com' },
        { name: 'chill vibes 24/7 🌙', type: ActivityType.Listening },
        { name: 'your musical journey 🚀', type: ActivityType.Watching }
    ];
    
    let i = 0;
    const updateActivity = () => {
        try {
            const activity = activities[i++ % activities.length];
            client.user.setActivity(activity);
        } catch (error) {
            console.log('⚠️ Failed to update activity'.yellow);
        }
    };
    
    // Set initial activity
    updateActivity();
    
    // Update activity every 15 seconds
    setInterval(updateActivity, 15000);
    
    console.log(`✨ Ready to spread good vibes! Use /play to get started!`.magenta);
    console.log(`🎵 Bot invite: https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=36700160&scope=bot%20applications.commands`.blue);
});

// IMPROVED interaction handler with TIMEOUT protection
client.on('interactionCreate', async (interaction) => {
    // Handle slash commands
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        // Create a timeout promise
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('Command execution timeout')), 14000); // 14 second timeout
        });

        try {
            console.log(`🎵 ${interaction.user.tag} used /${interaction.commandName} in ${interaction.guild?.name || 'DM'}`.cyan);
            
            // Race between command execution and timeout
            await Promise.race([
                command.execute(interaction),
                timeoutPromise
            ]);
            
        } catch (error) {
            console.error(`❌ Error executing ${interaction.commandName}:`, error.message);
            
            // Handle timeout specifically
            if (error.message.includes('timeout') || error.code === 10062) {
                console.log('⏰ Command timed out - this is common on slower hosting'.yellow);
                return; // Don't try to reply to timed out interactions
            }
            
            const reply = { content: '❌ There was an error while executing this command!', ephemeral: true };
            
            try {
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(reply);
                } else {
                    await interaction.reply(reply);
                }
            } catch (followUpError) {
                console.error('❌ Failed to send error message:', followUpError.message);
            }
        }
    }
    
    // Handle button interactions with timeout protection
    if (interaction.isButton()) {
        try {
            const queue = player.nodes.get(interaction.guildId);
            
            if (!queue || !queue.currentTrack) {
                return interaction.reply({
                    content: '❌ No music is currently playing!',
                    ephemeral: true
                });
            }
            
            // Check if user is in voice channel
            const voiceChannel = interaction.member?.voice?.channel;
            if (!voiceChannel || voiceChannel.id !== queue.connection?.channel?.id) {
                return interaction.reply({
                    content: '🎧 You need to be in the same voice channel as me to control the music!',
                    ephemeral: true
                });
            }
            
            switch (interaction.customId) {
                case 'pause_resume':
                    if (queue.node.isPaused()) {
                        queue.node.resume();
                        await interaction.reply({ content: '▶️ Music resumed!', ephemeral: true });
                    } else {
                        queue.node.pause();
                        await interaction.reply({ content: '⏸️ Music paused!', ephemeral: true });
                    }
                    break;
                    
                case 'skip':
                    const currentTrack = queue.currentTrack;
                    queue.node.skip();
                    await interaction.reply({ content: `⏭️ Skipped **${currentTrack?.title || 'track'}**!`, ephemeral: true });
                    break;
                    
                case 'stop':
                    queue.delete();
                    await interaction.reply({ content: '⏹️ Music stopped and queue cleared!', ephemeral: true });
                    break;
                    
                case 'shuffle':
                    if (queue.tracks.data.length === 0) {
                        await interaction.reply({ content: '⚠️ Nothing to shuffle!', ephemeral: true });
                        break;
                    }
                    queue.tracks.shuffle();
                    await interaction.reply({ content: '🔀 Queue shuffled!', ephemeral: true });
                    break;
                    
                case 'repeat':
                    const modes = ['Off', 'Track', 'Queue'];
                    const newMode = (queue.repeatMode + 1) % 3;
                    queue.setRepeatMode(newMode);
                    await interaction.reply({ content: `🔁 Repeat mode: **${modes[newMode]}**`, ephemeral: true });
                    break;
            }
        } catch (error) {
            console.error('❌ Button interaction error:', error.message);
            try {
                await interaction.reply({ content: '❌ An error occurred!', ephemeral: true });
            } catch (replyError) {
                console.error('❌ Failed to send button error message:', replyError.message);
            }
        }
    }
});

// Enhanced error handling
process.on('unhandledRejection', (reason, promise) => {
    console.log('🚨 Unhandled Rejection:'.red, reason?.message || reason);
    // Don't exit on unhandled rejections in production
});

process.on('uncaughtException', (err) => {
    console.log('🚨 Uncaught Exception:'.red, err.message);
    console.log('Stack:', err.stack);
    // Exit on uncaught exceptions
    process.exit(1);
});

// Validate environment variables before login
function validateEnvVars() {
    const requiredVars = ['DISCORD_TOKEN', 'CLIENT_ID'];
    const missing = [];
    
    for (const varName of requiredVars) {
        if (!process.env[varName]) {
            missing.push(varName);
        }
    }
    
    if (missing.length > 0) {
        console.error('❌ Missing environment variables:'.red, missing.join(', '));
        return false;
    }
    
    return true;
}

// Enhanced login with better error messages
async function loginBot() {
    console.log('🚀 Starting VibyMusic Discord Bot...'.rainbow);
    console.log('📋 Validating environment variables...'.blue);
    
    if (!validateEnvVars()) {
        console.error('❌ Environment validation failed. Bot cannot start.'.red);
        process.exit(1);
    }
    
    console.log('✅ Environment variables validated!'.green);
    console.log('🔐 Attempting to login to Discord...'.blue);
    
    try {
        await client.login(process.env.DISCORD_TOKEN);
        console.log('🎉 VibyMusic successfully connected to Discord!'.rainbow);
    } catch (error) {
        console.error('❌ Failed to login to Discord:'.red);
        console.error('Error code:'.red, error.code);
        console.error('Error message:'.red, error.message);
        process.exit(1);
    }
}

// Start the bot
loginBot();

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('👋 Received SIGINT, shutting down gracefully...'.yellow);
    client.destroy();
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('👋 Received SIGTERM, shutting down gracefully...'.yellow);
    client.destroy();
    process.exit(0);
});
